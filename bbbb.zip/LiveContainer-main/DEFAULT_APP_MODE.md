# Default App Mode

This fork adds an optional single-app launch mode.

## Behavior

- Choose **Default App** in LiveContainer Settings.
- On the next normal LiveContainer launch, the app list is skipped and the selected guest app is launched automatically.
- For 2 seconds after the guest app becomes active, a small `X` button appears in the top-right corner.
- Tapping the button marks the next launch as an escape launch, terminates the current guest/LiveContainer process, and opens the normal LiveContainer UI on the next launch.
- If the button is not tapped, it disappears after 2 seconds and the guest app continues normally.
- Explicit URL/deep-link launches and secondary LiveContainer instances are not overridden by the default-app auto launch.

## Implementation

- `LCDefaultAppManager` stores the selected app key in the LiveContainer app group.
- `LCTabView` performs the automatic launch after normal UI startup and gives deep-link routing a short head start.
- `LCBootstrap.m` installs the 2-second escape button inside the guest process, so the feature does not depend on the guest app's tweak configuration.
